COLOR_PALETTE = "burlywood", "brown3", "brown4", "gainsboro", "white"
TITLE_FONT = "arial", 40, "bold"
NORMAL_FONT = "arial", 13, "bold"
BUTTON_FONT = "arial", 14, "bold"
