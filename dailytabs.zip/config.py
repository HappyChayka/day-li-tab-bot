BOT_TOKEN = "6436220801:AAFQC-2clHRBxmzNK9_6X57AUoCzyQwPoAM"
STUDENTS_DB = "students.db"
BASE_WEBHOOK_URL = 'https://d5dfdot2qpr2pihi1h34.apigw.yandexcloud.net'
WEBHOOK_PATH = '/main-function'
WEB_SERVER_HOST = "127.0.0.1"
WEB_SERVER_PORT = 8080